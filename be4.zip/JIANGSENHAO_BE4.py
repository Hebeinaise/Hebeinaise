# -*- coding: utf-8 -*-
"""
Created on Mon Mar 12 10:46:56 2018

@author: 123
"""

import numpy as np
def sigmoide (x) :
    return 1/(1+np.exp(-x))
def derivee_de_sigmoide (x) :
    return x*(1-x)
# Les entrées
X =np.array ( [ [ 0,0,1 ] ,[ 0,1,1 ] ,[ 1,0,1 ] ,[ 1,1,1 ] ] )
# Les sorties ( i c i un vecteur )
Y = np. array ( [ [ 0 ,0 ,1 ,1 ] ] ) .T 
np.random.seed(1)
synapse0=2*np.random.random((3,1))-1
synapse0=np.array([[-0.5],[0.1],[0.9]])
couche_entree = X
for iter in range(10000) : 
    couche_sortie=sigmoide (np.dot(couche_entree,synapse0))
    erreur_couche_sortie=Y-couche_sortie
    delta_couche_sortie = erreur_couche_sortie*derivee_de_sigmoide ( couche_sortie )
    synapse0 += np. dot ( couche_entree .T, delta_couche_sortie )
print ( "Les sorties après l ’ apprentissage : " )
print ( couche_sortie )


synapse0=2*np.random.random((3,3))-1
synapse1=2*np.random.random((3,1))-1
nb_iterations=100000
#X=np.array ( [ [ 0,0,1 ] ,[ 0,1,1 ] ,[ 1,0,1 ] ,[ 1,1,1 ] ] )
#Y = np. array ( [ [ 0 ,1 ,1 ,0 ] ] ) .T
X=np.array ( [ [ 1,0,0 ] ,[ 0,0,0 ] ,[ 0,1,0 ]  ] )
Y = np. array ( [ [ 1 ,0 ,1  ] ] ) .T
couche_entree = X
err=[]
for j in range ( nb_iterations ) :
    couche_cachee = sigmoide(np.dot (couche_entree,synapse0) )
    couche_sortie = sigmoide(np.dot (couche_cachee,synapse1) )
    erreur_couche_sortie=Y-couche_sortie
    moy=np.mean(np.abs(erreur_couche_sortie))
    err.append(abs(moy) )
    if j%( nb_iterations //10) == 0: 
        print ( "Moyenne Erreur couche sortie : " + str (np.mean(np. abs( erreur_couche_sortie ) ) ) )
    delta_couche_sortie = erreur_couche_sortie * derivee_de_sigmoide ( couche_sortie )
    error_couche_cachee = delta_couche_sortie.dot (synapse1.T)
    delta_couche_cachee = error_couche_cachee*derivee_de_sigmoide (couche_cachee)
    synapse1 += couche_cachee.T.dot ( delta_couche_sortie )
    synapse0 += couche_entree.T.dot ( delta_couche_cachee )
print ( "Résultat de l ’ apprentissage : " )
print ( couche_sortie)
import matplotlib.pyplot as plt
myvec=np.array ( [ range ( len ( err ) ) , err ] )
plt.plot (myvec[ 0, ] ,myvec[ 1, ] ) ; plt .show()




#IV.4
def tangente (x) :
    return 2/(1+np.exp(-2*x))-1
def derivee_de_tangente (x) :
    return 1-tangente(x)**2
synapse0=2*np.random.random((3,3))-1
synapse1=2*np.random.random((3,1))-1
nb_iterations=100000
#X=np.array ( [ [ 0,0,1 ] ,[ 0,1,1 ] ,[ 1,0,1 ] ,[ 1,1,1 ] ] )
#Y = np. array ( [ [ 0 ,1 ,1 ,0 ] ] ) .T
X=np.array ( [ [ 1,0,0 ] ,[ 0,0,0 ] ,[ 0,1,0 ]  ] )
Y = np. array ( [ [ 1 ,0 ,1  ] ] ) .T
couche_entree = X
err=[]
for j in range ( nb_iterations ) :
    couche_cachee = tangente(np.dot (couche_entree,synapse0) )
    couche_sortie = tangente(np.dot (couche_cachee,synapse1) )
    erreur_couche_sortie=Y-couche_sortie
    moy=np.mean(np.abs(erreur_couche_sortie))
    err.append(abs(moy) )
    if j%( nb_iterations //10) == 0: 
        print ( "Moyenne Erreur couche sortie : " + str (np.mean(np. abs( erreur_couche_sortie ) ) ) )
    delta_couche_sortie = erreur_couche_sortie * derivee_de_tangente ( couche_sortie )
    error_couche_cachee = delta_couche_sortie.dot (synapse1.T)
    delta_couche_cachee = error_couche_cachee*derivee_de_tangente (couche_cachee)
    synapse1 += couche_cachee.T.dot ( delta_couche_sortie )
    synapse0 += couche_entree.T.dot ( delta_couche_cachee )
print ( "Résultat de l ’ apprentissage : " )
print ( couche_sortie)
import matplotlib.pyplot as plt
myvec=np.array ( [ range ( len ( err ) ) , err ] )
plt.plot (myvec[ 0, ] ,myvec[ 1, ] ) ; plt .show()


#IV.5 AJOUTER 0_5 ENTRE 0 ET 1
synapse0=2*np.random.random((3,3))-1
synapse1=2*np.random.random((3,3))-1
synapse2=2*np.random.random((3,1))-1

nb_iterations=100000
#X=np.array ( [ [ 0,0,1 ] ,[ 0,1,1 ] ,[ 1,0,1 ] ,[ 1,1,1 ] ] )
#Y = np. array ( [ [ 0 ,1 ,1 ,0 ] ] ) .T
X=np.array ( [ [ 1,0,0 ] ,[ 0,0,0 ] ,[ 0,1,0 ]  ] )
Y = np. array ( [ [ 1 ,0 ,1  ] ] ) .T
couche_entree = X
err=[]
for j in range ( nb_iterations ) :
    couche_cache1 = sigmoide(np.dot(couche_entree, synapse0))
    couche_cache2 = sigmoide(np.dot(couche_cache1, synapse1))
    couche_sortie = sigmoide(np.dot(couche_cache2, synapse2))
    erreur_couche_sortie = Y - couche_sortie
    delta_couche_sortie = erreur_couche_sortie *derivee_de_sigmoide(couche_sortie)
    erreur_couche_cache2 = delta_couche_sortie.dot(synapse2.T)
    delta_couche_cache2 = erreur_couche_cache2 *derivee_de_sigmoide(couche_cache2)
    erreur_couche_cache1 = delta_couche_cache2.dot(synapse1.T)
    delta_couche_cache1 = erreur_couche_cache1 *derivee_de_sigmoide(couche_cache1)
    synapse2 += np.dot(couche_cache2.T, delta_couche_sortie)
    synapse1 += np.dot(couche_cache1.T, delta_couche_cache2)
    synapse0 += np.dot(couche_entree.T, delta_couche_cache1)
    err.append(np.mean(np.abs(erreur_couche_sortie)))
    if j%( nb_iterations //10) == 0: 
        print ( "Moyenne Erreur couche sortie : " + str (np.mean(np. abs( erreur_couche_sortie ) ) ) )
print ( "Résultat de l ’ apprentissage : " )
print ( couche_sortie)
import matplotlib.pyplot as plt
myvec=np.array ( [ range ( len ( err ) ) , err ] )
plt.plot (myvec[ 0, ] ,myvec[ 1, ] ) ; plt .show()


def test(XXX):
    couche_cache1_test = sigmoide(np.dot(XXX, synapse0))
    couche_cache2_test = sigmoide(np.dot(couche_cache1_test, synapse1))
    couche_sortie_test = sigmoide(np.dot(couche_cache2_test, synapse2))
    return couche_sortie_test
X_test_1 = np.array([[1, 0, 0],
                    [0, 0, 0],
                    [0, 1, 0]])
X_test_2 = np.array([[1, 0, 0],
                    [0, 0, 0],
                    [1, 0, 0]])
X_test_3 = np.array([[1, 0, 0],
                    [0, 1, 0],
                    [0, 0, 0]])
X_test_4 = np.array([[1, 0, 0],
                    [0, 0, 0],
                    [0, 1, 0],
                    [1, 0, 0]])
X_test_5 = np.array([[1, 0, 0],
                    [0, 0, 0],
                    [0, 1, 1],
                    [1, 1, 1]])
X_test_6 = np.array([[0, 0, 0],
                    [0, 0, 0],
                    [0, 1, 1],
                    [0, 0, 0]])
print(test(X_test_1))
print(test(X_test_2))
print(test(X_test_3))
print(test(X_test_4))
print(test(X_test_5))
print(test(X_test_6))