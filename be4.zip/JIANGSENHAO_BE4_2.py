# -*- coding: utf-8 -*-
"""
Created on Sat Mar 24 12:51:48 2018

@author: 123
"""

def lecture_matrice_X_et_Y_from_file(nom_fic):
    os.chdir('C:\Users\123\Desktop\何以解忧\INF_TC1\be4')
    if not nom_fic in os.listdir():
        print("pb d'ouverture du fichier" + nom_fic)
        matrice_X_et_Y = []
        return
    mat_tous_les_caracteres = open(nom_fic).read()
    matrix_cars = [item.split()
                   for item in mat_tous_les_caracteres.split('\n')[:-1]]
    matrice_X_et_Y = [[int(row[i]) for i in range(len(row))]
                      for row in matrix_cars]
    return matrice_X_et_Y
def preparer_donnees(nom_fic):
    global matrice_X
    global matrice_cible_y
    global L_Gray_repr_binaire_de_0_a_9
    global vecteur_chiffres_0_9_cible_y
    matrice_X_et_Y = lecture_matrice_X_et_Y_from_file(nom_fic)
    if (matrice_X_et_Y == []):
        print("pb constitution de la matrice_X_et_Y")
        quit()
    matrice_X = np.array([row[:-1] for row in matrice_X_et_Y])
    matrice_cible_y = []
    for row in matrice_X_et_Y:
        matrice_cible_y.append(code_Gray_repr_binaire_de_0_a_9(row[-1]))
        # matrice_cible_y.append(row[-1])
    matrice_cible_y = np.array(matrice_cible_y)
    return (matrice_X, matrice_cible_y)


def code_Gray_repr_binaire_de_0_a_9(chiffre): 
    chiffre_temp = chiffre ^ (chiffre >> 1)
    return dem_to_bin(chiffre_temp)


def code_Gray_to_demical(gray):
    chiffre_temp = int(bin_to_dem(gray))
    enum = [0, 1, 3, 2, 6, 7, 5, 4, 12, 13]
    return enum.index(chiffre_temp)


def bin_to_dem(bin_chiffre):
    bin_chiffre = list(bin_chiffre)
    bin_chiffre.reverse()
    dem_chiffre = 0
    for i in range(len(bin_chiffre)):
        dem_chiffre += bin_chiffre[i] * 2 ** i
    return dem_chiffre


def dem_to_bin(dem_chiffre):
    bin_chiffre = [0, 0, 0, 0]
    for i in range(4):
        bin_chiffre[i] = dem_chiffre % 2
        dem_chiffre = int(dem_chiffre / 2)
    bin_chiffre.reverse()
    return bin_chiffre


def my_modify(x):
    if x < 0.1:
        return 0
    elif x > 0.9:
        return 1
    else:
        return x


def my_modify_array(X):
    Y = X
    for i in range(len(Y)):
        for j in range(len(Y[0])):
            Y[i][j] = my_modify(X[i][j])
    return Y


def test_erreur(X, X_test):
    err = 0
    for i in range(len(X)):
        for j in range(len(X[0])):
            err += abs(X[i][j]-X_test[i][j])
    return err


if __name__ == '__main__':
    preparer_donnees('train.data')