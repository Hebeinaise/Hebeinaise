# -*- coding: utf-8 -*-
"""
Created on Thu May  3 15:44:51 2018

@author: 123
"""


import numpy as np
def sigmoide (x) :
    return 1/(1+np.exp(-x))
def derivee_de_sigmoide (x) :
    return x*(1-x)
synapse0=2*np.random.random((3,3))-1
synapse1=2*np.random.random((3,1))-1
nb_iterations=(2000)
#X=np.array ( [ [ 0,0,1 ] ,[ 0,1,1 ] ,[ 1,0,1 ] ,[ 1,1,1 ] ] )
#Y = np. array ( [ [ 0 ,1 ,1 ,0 ] ] ) .T
#X=np.array ( [ [ 1,0,0 ] ,[ 0,0,0 ] ,[ 0,1,0 ]  ] )
#Y = np. array ( [ [ 1 ,0 ,1  ] ] ) .T
#IV.4
def tangente (x) :
    return 2/(1+np.exp(-2*x))-1
def derivee_de_tangente (x) :
    return 1-tangente(x)**2

synapse0=2*np.random.random((3,3))-1
synapse1=2*np.random.random((3,1))-1
nb_iterations=100000
X=np.array ([[0,0,0] ,[ 0,0,1 ], [0,1,0],[1,0,0],[1,1,0],[ 0,1,1 ] ,[ 1,0,1 ] ,[ 1,1,1 ] ] )
Y = np. array ( [ [ 0 ,0 ,0 ,0,1,0,0,0 ] ] ) .T
#X=np.array ( [ [ 1,0,0 ] ,[ 0,0,0 ] ,[ 0,1,0 ]  ] )
#Y = np. array ( [ [ 1 ,0 ,1  ] ] ) .T
couche_entree = X
err=[]
for j in range ( nb_iterations ) :
    couche_cachee = sigmoide(np.dot (couche_entree,synapse0) )
    couche_sortie = sigmoide(np.dot (couche_cachee,synapse1) )
    erreur_couche_sortie=Y-couche_sortie
    moy=np.mean(np.abs(erreur_couche_sortie))
    err.append(abs(moy) )
    if j%( nb_iterations //10) == 0: 
        print ( "Moyenne Erreur couche sortie : " + str (np.mean(np. abs( erreur_couche_sortie ) ) ) )
    delta_couche_sortie = erreur_couche_sortie * derivee_de_sigmoide ( couche_sortie )
    error_couche_cachee = delta_couche_sortie.dot (synapse1.T)
    delta_couche_cachee = error_couche_cachee*derivee_de_sigmoide (couche_cachee)
    synapse1 += couche_cachee.T.dot ( delta_couche_sortie )
    synapse0 += couche_entree.T.dot ( delta_couche_cachee )
print ( "Résultat de l ’ apprentissage : " )
print ( couche_sortie)
import matplotlib.pyplot as plt
myvec=np.array ( [ range ( len ( err ) ) , err ] )
plt.plot (myvec[ 0, ] ,myvec[ 1, ] ) ; plt .show()

synapse0=2*np.random.random((3,4))-1
synapse1=2*np.random.random((4,4))-1
synapse2=2*np.random.random((4,1))-1

nb_iterations=100000
#X=np.array ( [ [ 0,0,1 ] ,[ 0,1,1 ] ,[ 1,0,1 ] ,[ 1,1,1 ] ] )
#Y = np. array ( [ [ 0 ,1 ,1 ,0 ] ] ) .T
#X=np.array ( [ [ 1,0,0 ] ,[ 0,0,0 ] ,[ 0,1,0 ]  ] )
#Y = np. array ( [ [ 1 ,0 ,1  ] ] ) .T
X=np.array ( [[0,0,0], [ 0,0,1 ] ,[0,1,0],[1,0,0],[1,1,0],[ 0,1,1 ] ,[ 1,0,1 ] ,[ 1,1,1 ] ] )
Y = np. array ( [ [ 0 ,0 ,0 ,0,1,0,0,0 ] ] ) .T
couche_entree = X
err=[]
for j in range ( nb_iterations ) :
    couche_cache1 = sigmoide(np.dot(couche_entree, synapse0))
    couche_cache2 = sigmoide(np.dot(couche_cache1, synapse1))
    couche_sortie = sigmoide(np.dot(couche_cache2, synapse2))
    erreur_couche_sortie = Y - couche_sortie
    delta_couche_sortie = erreur_couche_sortie *derivee_de_sigmoide(couche_sortie)
    erreur_couche_cache2 = delta_couche_sortie.dot(synapse2.T)
    delta_couche_cache2 = erreur_couche_cache2 *derivee_de_sigmoide(couche_cache2)
    erreur_couche_cache1 = delta_couche_cache2.dot(synapse1.T)
    delta_couche_cache1 = erreur_couche_cache1 *derivee_de_sigmoide(couche_cache1)
    synapse2 += np.dot(couche_cache2.T, delta_couche_sortie)
    synapse1 += np.dot(couche_cache1.T, delta_couche_cache2)
    synapse0 += np.dot(couche_entree.T, delta_couche_cache1)
    err.append(np.mean(np.abs(erreur_couche_sortie)))
    if j%( nb_iterations //10) == 0: 
        print ( "Moyenne Erreur couche sortie : " + str (np.mean(np. abs( erreur_couche_sortie ) ) ) )
print ( "Résultat de l ’ apprentissage : " )
print ( couche_sortie)
import matplotlib.pyplot as plt
myvec=np.array ( [ range ( len ( err ) ) , err ] )
plt.plot (myvec[ 0, ] ,myvec[ 1, ] ) ; plt .show()

